# Q9 32K 加密 IP 交付包

IP 标识：`user.local:accelerator:q9_accelerator_ip:1.0`

这是一份固定 Q933 / 32K Compact8 配置的 PL 加速器 IP。公开集成接口，核心实现
采用 IEEE 1735 V2 加密。使用方可通过 Vivado 进行集成、编译和生成 bitstream。

## 加入 Vivado

1. 将本包解压到固定目录。
2. 在 Vivado 2025.2 的 Settings → IP → Repository 添加本包的 `ip_repo` 目录。
3. 更新 IP Catalog，搜索 `q9_accelerator_ip`，添加到 Block Design。
4. 按下表连接时钟、AXI 和存储；加载与地址表一致的模型权重后再提交计算。

也可在 Tcl 使用：

```tcl
set_property ip_repo_paths {/absolute/path/to/ip_repo} [current_project]
update_ip_catalog
create_ip -vlnv user.local:accelerator:q9_accelerator_ip:1.0 -module_name my_q9
```

## 公开接口

| 接口 | 含义 | 时钟域 |
|---|---|---|
| `s_axi_ctrl` | AXI4-Lite，32位数据、16位地址，64KiB寄存器窗口 | `core_clk` |
| `m_axi_weight_pl` | AXI4只读，512位数据、34位地址、4位ID | `ui_clk` |
| `m_axi_weight_ps` | AXI4只读，512位数据、34位地址、4位ID | `ui_clk` |
| `m_axi_state` | AXI4读写，512位数据、34位地址、4位ID | `core_clk` |
| `core_aresetn` | 低有效复位；两路时钟稳定后释放 | 与core时钟同步释放 |
| `board_errors_i` | 外部存储/桥接故障；无额外故障时接0 | `core_clk` |
| `busy_o` / `done_o` | 计算忙与单token完成指示；软件仍应读寄存器确认事务 | `core_clk` |

本配置时钟接口标称为 core=250MHz、ui=300.120048MHz；这是集成配置，独立设计
是否满足时序必须由使用方重新布局布线验证，不能当作时序签核。

`m_axi_state` 与 `m_axi_weight_pl` 必须最终访问同一个 PL 存储地址空间，不能
接到两份彼此不一致的内存。应使用 AXI 时钟转换和仲裁/互连合流。
`m_axi_weight_ps` 连接另一份权重地址空间；若对接 Zynq PS 的不同位宽端口，
需要位宽转换及相应地址映射。本IP不包含PS、MIG、板级时钟发生器或物理引脚约束。

当前固定模型布局由 `rom/*bases*.mem`、公开 `docs/interface.json` 及下列地址约定
共同定义。外部模型/状态存储不得互相覆盖；地址均是IP接口看到的字节地址。

| PL 区域 | 起始地址 |
|---|---|
| Embedding | `0x052064000` |
| LM head PL部分 | `0x15FBEE000` |
| KV codes / parameters / extrema | `0x190000000` / `0x1A0000000` / `0x1A4000000` |
| Gamma / RAW tail / GDN state | `0x1EFB40000` / `0x1EFC00000` / `0x1F0400000` |
| Conv系数 / RoPE / score scratch | `0x1F3600000` / `0x1F3780000` / `0x1FE800000` |

PS权重通道LM-head基址为 `0x080000000`；其余逐层权重地址来自ROM表。
本包不附带完整模型权重、PS视觉编码器、Linux服务或SSD会话软件。

## 寄存器识别与调用

公开头文件在 `ip_repo/q9_accelerator_1_0/docs/q9_ip_regs.h`。

- `0x1E0`：model ABI = `0x51393333`。
- `0x1E4`：上下文容量 = 32768。
- `0x210`：session ABI = `0x51395333`。
- `0x100/0x104/0x108`：token / position / context 配置。
- `0x000`：写1提交一次计算；须检查AXI BRESP及事务完成记录，不应只看旧DONE位。

量化权重、位置、会话状态与该ABI必须一致。实际DDR映射和驱动初始化仍由集成方
负责。它不是接受字符串并自行分词的独立模型服务器。

## 哪些内容公开，哪些内容受到保护

明文只包含顶层端口连接、IP-XACT/XGUI元数据、接口文档、接口冒烟测试和必要的
ROM初始化数据（查找表、层地址表及预配置常量）。这些数据可见，可据此进行集成。
实现算法的RTL位于 `hdl/q9_core.vp` 加密载荷中，不交付其明文。

加密权利设置允许工具生成bitstream，同时禁止核心网表导出、内部探针插入、
配置内容查看及人工修改。接口、资源占用、部分层级/时序信息仍可能可见。
该权限由支持IEEE1735的AMD工具执行；未增加板卡绑定、次数/时间限制或在线授权。

仅包含AMD工具密钥，仿真使用Vivado/XSIM。ModelSim/Questa等其他工具需要另行
制作支持相应工具密钥的版本，不能直接假设本包可用。

## 验证范围

最终实际验证记录见包内 `VALIDATION.json`。RTL导入/接口仿真不等同于完整9B模型
重新综合、布局布线或上板验收；本封装的物理实现和模型级功能不能借用未重新验证
的结果冒充通过。本次仅新增独立交付工程，原构建中的工程文件保持不变。
