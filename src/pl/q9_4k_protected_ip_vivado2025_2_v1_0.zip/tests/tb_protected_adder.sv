`timescale 1ns/1ps
module tb_protected_adder;
reg [79:0] a=0,b=0;wire[79:0]sum;
qwen35_carry_prefix80_49 dut(.a(a),.b(b),.sum(sum));
integer i,seed=20261103,fd;
initial begin
 for(i=0;i<1024;i=i+1)begin
  a={$random(seed),$random(seed),$random(seed)};b={$random(seed),$random(seed),$random(seed)};
  if(i==0)begin a=0;b=0;end
  if(i==1)begin a={80{1'b1}};b=1;end
  #2;if(sum!==(a+b))$fatal(1,"PROTECTED_ADDER_MISMATCH i=%0d",i);
 end
 fd=$fopen("protected_adder_pass.txt","w");$fdisplay(fd,"Q9_4K_ENCRYPTED_ADDER_PASS checks=1024");$fclose(fd);
 $display("Q9_4K_ENCRYPTED_ADDER_PASS checks=1024");$finish;
end
initial begin #5000;$fatal(1,"PROTECTED_ADDER_TIMEOUT");end
endmodule
