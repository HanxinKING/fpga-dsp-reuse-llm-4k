lassign $argv root out
set_param general.maxThreads 2
set rc [catch {
 set source [file join $root source rtl qwen35_carry_prefix80_49.sv]
 create_project -in_memory -part xczu19eg-ffvc1760-2-i
 read_verilog -sv $source
 synth_design -top qwen35_carry_prefix80_49 -mode out_of_context -part xczu19eg-ffvc1760-2-i -directive Default
 report_utilization -file [file join $out protected_adder_utilization.rpt]
 set blocked [catch {write_verilog [file join $out attempted_export.v]} message]
 set f [open [file join $out export_attempt.txt] w];puts $f "return_code=$blocked\n$message";close $f
 if {!$blocked || ![regexp -nocase {encrypt|protect|rights|export|available modules} $message]} {error EXPECTED_PROTECTED_EXPORT_BLOCK_MISSING}
 puts Q9_4K_ACTUAL_ENCRYPTED_MODULE_SYNTH_AND_EXPORT_GUARD_PASS
 close_design;close_project
 create_project carry_sim [file join $out sim] -part xczu19eg-ffvc1760-2-i
 add_files $source
 add_files -fileset sim_1 [file join $root tests tb_protected_adder.sv]
 set_property top tb_protected_adder [get_filesets sim_1]
 set_property xsim.simulate.runtime 5us [get_filesets sim_1]
 launch_simulation -mode behavioral
 set marker [file join $out sim carry_sim.sim sim_1 behav xsim protected_adder_pass.txt]
 if {![file exists $marker]} {error PROTECTED_ADDER_SIM_MARKER_MISSING}
 set f [open $marker];set data [read $f];close $f;puts $data
 if {[string first {Q9_4K_ENCRYPTED_ADDER_PASS checks=1024} $data]<0} {error PROTECTED_ADDER_SIM_FAILED}
 close_sim;close_project
} why options]
if {$rc} {puts stderr $why;puts stderr [dict get $options -errorinfo]}
exit $rc
