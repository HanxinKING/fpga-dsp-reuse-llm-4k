set root [file normalize [file join [file dirname [info script]] ..]]
set f [open [file join $root sources.txt]];set lines [split [read $f] "\n"];close $f
set_property include_dirs [list [file join $root source board] [file join $root source rtl]] [current_fileset]
foreach rel $lines {set rel [string trim $rel];if {$rel ne {}} {read_verilog -sv [file join $root $rel]}}
foreach f [glob [file join $root source data *.mem]] {add_files -norecurse $f;set_property file_type {Memory Initialization Files} [get_files $f]}
puts Q9_4K_PUBLIC_TOP_AND_PROTECTED_CORE_IMPORTED
