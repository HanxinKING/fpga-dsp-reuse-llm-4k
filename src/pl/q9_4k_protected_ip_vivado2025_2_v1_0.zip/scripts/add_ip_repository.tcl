set root [file normalize [file join [file dirname [info script]] ..]]
set_property ip_repo_paths [concat [get_property ip_repo_paths [current_project]] [list [file join $root ip_repo]]] [current_project]
update_ip_catalog
create_ip -vlnv user.local:accelerator:q9_accelerator_4k_ip:1.0 -module_name q9_4k
