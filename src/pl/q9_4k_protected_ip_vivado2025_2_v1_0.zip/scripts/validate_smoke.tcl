lassign $argv root out
set_param general.maxThreads 2
set code [catch {
 set repo [file join $root ip_repo q9_accelerator_4k_1_0]
 create_project consumer [file join $out project] -part xczu19eg-ffvc1760-2-i
 set_property ip_repo_paths [list [file dirname $repo]] [current_project]
 update_ip_catalog
 create_ip -vlnv user.local:accelerator:q9_accelerator_4k_ip:1.0 -module_name q9_consumer_catalog_test
 report_ip_status -file [file join $out ip_status.rpt]
 puts Q9_CLEAN_CONSUMER_CATALOG_IMPORT_PASS
 close_project
 create_project smoke [file join $out simulation] -part xczu19eg-ffvc1760-2-i
 set_property XPM_LIBRARIES {XPM_CDC XPM_FIFO XPM_MEMORY} [current_project]
 set repo [file join $root ip_repo q9_accelerator_4k_1_0]
 set paths [list [file join $repo hdl q9_accelerator_4k_ip.v] [file join $repo hdl q9_accelerator_4k_impl.sv]]
 set f [open [file join $root sources.txt]];set source_lines [split [read $f] "\n"];close $f
 foreach rel $source_lines {set rel [string trim $rel];if {$rel eq {} || [string match {source/physical/*} $rel]} {continue};lappend paths [file join $root $rel]}
 add_files -norecurse $paths
 foreach f [glob [file join $repo rom *.mem]] {add_files $f;set_property file_type {Memory Initialization Files} [get_files $f]}
 add_files -fileset sim_1 [file join $repo tests tb_q9_ip.sv]
 set_property top tb_q9_ip [get_filesets sim_1]
 set_property xsim.simulate.runtime 20us [get_filesets sim_1]
 launch_simulation -mode behavioral
 set result [file join $out simulation smoke.sim sim_1 behav xsim Q9_4K_IP_AXI_SMOKE_PASS.txt]
 if {![file exists $result]} {error IP_AXI_SMOKE_MARKER_MISSING}
 set f [open $result];set data [read $f];close $f
 if {[string first {Q9_4K_IP_AXI_SMOKE_PASS checks=7} $data]<0} {error IP_AXI_SMOKE_FAILED}
 puts $data
 close_sim
 close_project
} why opts]
if {$code} {puts stderr $why;puts stderr [dict get $opts -errorinfo]}
exit $code
