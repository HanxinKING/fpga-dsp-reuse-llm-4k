lassign $argv root out
set_param general.maxThreads 2
set rc [catch {
 create_project catalog_consumer [file join $out project] -part xczu19eg-ffvc1760-2-i
 set_property XPM_LIBRARIES {XPM_CDC XPM_FIFO XPM_MEMORY} [current_project]
 set_property ip_repo_paths [list [file join $root ip_repo]] [current_project]
 update_ip_catalog
 create_ip -vlnv user.local:accelerator:q9_accelerator_4k_ip:1.0 -module_name q9_catalog_consumer
 set ip [get_ips q9_catalog_consumer]
 set xci [get_files -all -quiet *q9_catalog_consumer.xci]
 if {[llength $xci]!=1} {error EXPECT_EXACT_ONE_CONSUMER_XCI}
 set_property generate_synth_checkpoint false $xci
 generate_target all $ip
 set_property top q9_catalog_consumer [current_fileset]
 update_compile_order -fileset sources_1
 synth_design -rtl -mode out_of_context -top q9_catalog_consumer -part xczu19eg-ffvc1760-2-i
 set boxes [get_cells -hier -quiet -filter {IS_BLACKBOX == 1}]
 foreach cell $boxes {
  if {[get_property REF_NAME $cell] ne {qwen35_hybrid_board_core}} {error "UNEXPECTED_RTL_BLACKBOX $cell"}
 }
 puts "Q9_4K_SECURE_RTL_VIEW_STUBS [llength $boxes]"
 close_design
 add_files -fileset sim_1 [file join $root tests tb_catalog_q9_4k.sv]
 set_property top tb_catalog_q9_4k [get_filesets sim_1]
 set_property xsim.simulate.runtime 20us [get_filesets sim_1]
 launch_simulation -mode behavioral
 set marker [file join $out project catalog_consumer.sim sim_1 behav xsim Q9_4K_CATALOG_AXI_SMOKE_PASS.txt]
 if {![file exists $marker]} {error CLEAN_CATALOG_SIM_MARKER_MISSING}
 set f [open $marker];set data [read $f];close $f;puts $data
 if {[string first {Q9_4K_CATALOG_AXI_SMOKE_PASS checks=7} $data]<0} {error CLEAN_CATALOG_SIM_FAILED}
 close_sim;close_project
 puts Q9_4K_CLEAN_CATALOG_GENERATE_ELABORATE_AND_SIM_PASS
} why options]
if {$rc} {puts stderr $why;puts stderr [dict get $options -errorinfo]}
exit $rc
